namespace Chomikuj
{
    internal enum SortType
    {
        Date = 0,
        Size = 1,
        Type = 2,
        Name = 3
    }
}