namespace Chomikuj
{
    internal enum OrderBy
    {
        Ascending = 0,
        Descending = 1
    }
}