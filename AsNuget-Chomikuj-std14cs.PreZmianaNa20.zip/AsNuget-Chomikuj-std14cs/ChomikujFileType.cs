﻿namespace Chomikuj
{
    public enum ChomikujFileType
    {
        Unknown = 0,
        Audio,
        Image,
        Document,
        Video,
        Archive,
        Program,
    }
}